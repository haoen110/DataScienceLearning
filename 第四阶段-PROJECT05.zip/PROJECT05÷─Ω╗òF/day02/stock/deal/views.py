from django.shortcuts import render
from .models import *
from userinfo.models import *
from stocks.models import *
from django.db.models import F
import datetime
import decimal
import json
# Create your views here.


# 用户user,买卖类型sob,股票代码stockNo,数量amount,金额price,交易密码tradpwd,浮动价格price_range
def deal(user,sob,stockNo,amount,price,tradpwd,price_range):
    result={}
    if sob == "sale":
        hold = Hold.objects.get(user=user, stock__stonumber=stockNo)
        fund = Fund.objects.get(user=user)
        new_amount = hold.amount - hold.frozen
        stock = Stock.objects.get(stonumber=stockNo)
        datetimes = datetime.datetime.now()
        stockdetail = json.dumps(stock) #查看models
        if new_amount >= int(amount):
            hold.frozen = hold.frozen + int(amount)
            hold.save()
            range = (decimal.Decimal(price),decimal.Decimal(price)+decimal.Decimal(price_range))
            # 查询范围：字段__range=(start,end)
            buy_stock = BOSStock.objects.filter(stock__stonumber=stockNo,role=0,price__range=range)
            if len(buy_stock)<=0:
                bosstock = BOSStock()
                bosstock.user = user
                bosstock.stock = stock
                bosstock.role = 1
                bosstock.price = decimal.Decimal(price)
                bosstock.amount = int(amount)
                bosstock.datetime = datetimes
                bosstock.save()
                result['msg']="无买入股票，卖出股票已挂单"
                return result
            else:
                for st in buy_stock:
                    if int(amount) >= st.amount:
                        amount = int(amount) - st.amount
                        hold.amount = hold.amount - st.amount
                        hold.frozen = hold.frozen - st.amount
                        hold.save()
                        fund.money = fund.money + st.amount*st.price
                        fund.save()
                        buser = Hold.objects.filter(user=st.user,stock=stock)
                        if len(buser) > 0:
                            buser = Hold.objects.filter(user=st.user,stock=stock).update(amount=F('amount')+st.amount)
                        else:
                            buser = Hold.objects.create(user=st.user,stock=stock,amount=int(st.amount),frozen=0)
                        bfuser = Fund.objects.filter(user=user)
                        bfuser.money = bfuser.money - st.amount*st.price
                        bfuser.frozen_money = bfuser.frozen_money - st.amount*st.price
                        bfuser.save()
                        DealStock.objects.create(suser=user,bsuer=st.user,price=st.price,amount=st.amount,datetime=datetimes,stock=stockdetail)
                        st.delete()
                    else:
                        st.amount = st.amount - int(amount)
                        st.save()
                        hold.amount = hold.amount - int(amount)
                        hold.frozen = hold.frozen - int(amount)
                        hold.save()
                        fund.money = fund.money +int(amount)*st.price
                        fund.save()
                        if len(buser) > 0:
                            buser = Hold.objects.filter(user=st.user, stock=stock).update(amount=F('amount') + int(amount))
                        else:
                            buser = Hold.objects.create(user=st.user, stock=stock, amount=int(amount), frozen=0)
                        DealStock.objects.create(suser=user, bsuer=st.user, price=st.price, amount=int(amount), datetime=datetimes,stock=stockdetail)
                if int(amount)>0:
                    bosstock = BOSStock()
                    bosstock.user = user
                    bosstock.stock = stock
                    bosstock.role = 1
                    bosstock.price = decimal.Decimal(price)
                    bosstock.amount = int(amount)
                    bosstock.datetime = datetimes
                    bosstock.save()
                    result['msg']='剩余股票已挂单'
                    return result
                else:
                    result['msg']='股票已成交'
                    return result
        else:
            result['msg']='所持股票数量不足'
            return result
    elif sob == "buy":










