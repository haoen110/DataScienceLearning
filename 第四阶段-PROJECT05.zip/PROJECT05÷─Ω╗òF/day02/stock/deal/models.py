from django.db import models
from userinfo.models import *
from stocks.models import *
# Create your models here.
BOS_CHOICES = (
    (0,'买'),
    (1,'卖'),
)

class SelfStock(models.Model):
    user = models.ForeignKey(UserInfo)
    stock = models.ForeignKey(Stock)

    def __str__(self):
        return self.user.username


class BOSStock(models.Model):
    user = models.ForeignKey(UserInfo)
    stock = models.ForeignKey(Stock)
    amount = models.IntegerField('挂单数量')
    price = models.DecimalField('挂单价格',decimal_places=2,max_digits=8)
    role = models.IntegerField('买卖角色',choices=BOS_CHOICES,default=0)
    datetime = models.DateTimeField('挂单时间',auto_now_add=True)

    def __str__(self):
        return self.user.username


class DealStock(models.Model):
    # 一张表两个字段foreignkey到同一张表，需要加入related_name参数属性，用于区分
    suser = models.ForeignKey(UserInfo,related_name='suser')
    buser = models.ForeignKey(UserInfo,related_name='buser')
    price = models.DecimalField('交易价格',max_digits=8,decimal_places=2)
    amount = models.IntegerField('交易数量')
    datetime = models.DateTimeField('交易时间',auto_now_add=True)
    stock = models.CharField('交易股票',max_length=50,null=False)


