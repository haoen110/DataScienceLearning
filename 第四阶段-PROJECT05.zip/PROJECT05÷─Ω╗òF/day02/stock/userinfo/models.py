from django.db import models
from django.contrib.auth.models import AbstractUser
from stocks.models import *
# Create your models here.

MLIST_ROLE = (
    (0,'买'),
    (1,'卖'),
    (2,'充值'),
    (3,'提现'),
)

# 使用django自带user表进行扩展，继承user表
class UserInfo(AbstractUser):
    mobile = models.CharField('电话', max_length=50, null=True, unique=True)
    email = models.EmailField('email')
    identity = models.CharField('身份证号', max_length=50, null=False)
    isActive = models.BooleanField('是否激活', default=False)
    isBan = models.BooleanField('是否禁用', default=False)

    def __str__(self):
        return self.username


class Fund(models.Model):
    user = models.OneToOneField(UserInfo)
    money = models.DecimalField('资金',max_digits=8,decimal_places=2,null=True)
    frozen_money = models.DecimalField('冻结资金',max_digits=8,decimal_places=2,null=True)
    tradepwd = models.CharField('交易密码', max_length=20,null=False)

    def __str__(self):
        return self.user.username


class MoneyList(models.Model):
    money  = models.DecimalField('记录金额',max_digits=8,decimal_places=2,null=True)
    user = models.ForeignKey(UserInfo)
    role = models.IntegerField('记录名称',choices=MLIST_ROLE,default=0)

    def __str__(self):
        return self.user.username


class Bank(models.Model):
    user = models.ForeignKey(UserInfo)
    bankNo = models.CharField('卡号',max_length=50)
    bank = models.CharField('开户行',max_length=50)
    time = models.DateTimeField('开户时间')

    def __str__(self):
        return self.user.username


class Hold(models.Model):
    user = models.ForeignKey(UserInfo)
    stock = models.ForeignKey(Stock)
    amount = models.IntegerField('数量')
    frozen = models.IntegerField('冻结')

    def __str__(self):
        return self.user.username

#     持仓表(Hold)
#         id
#         user(用户，F)
#         stock(股票，F)
#         amount(持有数量，Int)
#         frozen(冻结)

