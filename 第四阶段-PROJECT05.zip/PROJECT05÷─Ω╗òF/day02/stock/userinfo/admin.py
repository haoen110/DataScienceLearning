from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(UserInfo)
admin.site.register(Fund)
admin.site.register(MoneyList)
admin.site.register(Bank)
admin.site.register(Hold)