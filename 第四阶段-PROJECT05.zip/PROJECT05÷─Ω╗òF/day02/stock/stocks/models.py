from django.db import models

# Create your models here.

class Stock(models.Model):
    stonumber = models.CharField('股票代码',max_length=20,null=False)
    company_name = models.CharField('公司名称',max_length=50,null=False)
    industry = models.CharField('细分行业',max_length=20, null=False)
    area = models.CharField('地区',max_length=200,null=False)
    pe = models.DecimalField('市盈率',max_digits=8,decimal_places=2,null=False)
    outstanding = models.DecimalField('流通股本',max_digits=8,decimal_places=2,null=False)
    totals = models.DecimalField('总股本',max_digits=8,decimal_places=2,null=False)
    totalAssets = models.DecimalField('总资产',max_digits=8,decimal_places=2,null=False)
    liquidAssets = models.DecimalField('流动资产',max_digits=8,decimal_places=2,null=False)
    fixedAssets = models.DecimalField('固定资产',max_digits=8,decimal_places=2,null=False)
    reserved = models.DecimalField('公积金',max_digits=8,decimal_places=2,null=False)
    reservedPerShare = models.DecimalField('每股公积金',max_digits=8,decimal_places=2,null=False)
    esp = models.DecimalField('每股收益',max_digits=8,decimal_places=2,null=False)
    bvps = models.DecimalField('每股净资',max_digits=8,decimal_places=2,null=False)
    pb = models.DecimalField('市净率',max_digits=8,decimal_places=2,null=False)
    timeToMarket = models.DateTimeField('上市日期')

    def __str__(self):
        return self.company_name


class Adlink(models.Model):
    title = models.CharField('名称',max_length=50,null=False)
    adimg = models.ImageField('广告图片',upload_to='static/image/ad',default='normal.png')
    adurl = models.URLField('广告链接',null=False)

    def __str__(self):
        return self.title
