
# 人脸识别

### 1.视频捕捉

视频捕捉设备->图像帧


```python
import cv2 as cv
import matplotlib.pyplot as plt

vc = cv.VideoCapture(0)  # 摄像头个数，0就是一个

frame = vc.read()[1]  # 得到几帧
frame = vc.read()[1]  # 得到几帧
cv.imshow('VideoCapture', frame)
cv.waitKey(0)

frame_c = cv.cvtColor(frame, cv.COLOR_BGR2RGB)  # 转换颜色

plt.imshow(frame_c)
plt.show()

vc.release()
cv.destroyAllWindows()
```


![png](output_1_0.png)



```python
import cv2 as cv
vc = cv.VideoCapture(0)
while True:
    frame = vc.read()[1]
    cv.imshow('VideoCapture', frame)
    if cv.waitKey(33) == 27:  # 只会阻塞33毫秒， 27为esc键，作为退出条件
        break
vc.release()
cv.destroyAllWindows()
```

### 2. 人脸定位

哈尔级联人脸定位


```python
# 哈尔级联人脸定位
import cv2 as cv

# 哈尔级联人脸定位器，存有有关人脸的各种特征
fd = cv.CascadeClassifier('../data/haar/face.xml')
ed = cv.CascadeClassifier('../data/haar/eye.xml')
nd = cv.CascadeClassifier('../data/haar/nose.xml')

vc = cv.VideoCapture(0)
while True:
    frame = vc.read()[1]
    faces = fd.detectMultiScale(frame, 1.3, 5)  # 1.3cm设置人脸大小，5是最小人脸个数，返回描述人脸的元祖构成的列表
    for l, t, w, h in faces:  # 矩形
        a, b = int(w / 2), int(h / 2)
        # cv.ellipse(图像, 椭圆心, 半径, 旋转角,
        #     起始角, 终止角, 颜色, 线宽)
        cv.ellipse(frame, (l + a, t + b), (a, b), 0, 0, 360, (255, 0, 255), 2)
        face = frame[t:t + h, l:l + w]
        
        eyes = ed.detectMultiScale(face, 1.3, 5)
        for l, t, w, h in eyes:
            a, b = int(w / 2), int(h / 2)
            cv.ellipse(face, (l + a, t + b),
                       (a, b), 0, 0, 360,
                       (0, 255, 0), 2)
            
        noses = nd.detectMultiScale(face, 1.3, 5)
        for l, t, w, h in noses:
            a, b = int(w / 2), int(h / 2)
            cv.ellipse(face, (l + a, t + b),
                       (a, b), 0, 0, 360,
                       (0, 255, 255), 2)
    cv.imshow('VideoCapture', frame)
    if cv.waitKey(33) == 27:
        break
        
vc.release()
cv.destroyAllWindows()
```

### 3. 简单人脸识别：OpenCV的LBPH(局部二值模式直方图)


```python
import os
import numpy as np
import cv2 as cv
import sklearn.preprocessing as sp


fd = cv.CascadeClassifier('../data/haar/face.xml')

def search_faces(directory):
    directory = os.path.normpath(directory)
    if not os.path.isdir(directory):
        raise IOError("The directory '" + directory + "' doesn't exist!")
        
    faces = {}
    for curdir, subdirs, files in os.walk(directory):
        for jpeg in (file for file in files if file.endswith('.jpg')):
            path = os.path.join(curdir, jpeg)
            label = path.split(os.path.sep)[-2]
            if label not in faces:
                faces[label] = []
            faces[label].append(path)
    return faces

# 构建训练集
train_faces = search_faces('../data/faces/training')
codec = sp.LabelEncoder()
codec.fit(list(train_faces.keys()))
train_x, train_y = [], []
for label, filenames in train_faces.items():
    for filename in filenames:
        image = cv.imread(filename)
        gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
        faces = fd.detectMultiScale(gray, 1.1, 2, minSize=(100, 100))
        for l, t, w, h in faces:
            train_x.append(gray[t:t + h, l:l + w])  # 将脸切出来
            train_y.append(codec.transform([label])[0])  # 将字符串变成编码值取出
train_y = np.array(train_y)  # 转换为数组模式

# 局部二值模式直方图人脸识别分类器
model = cv.face.LBPHFaceRecognizer_create()
model.train(train_x, train_y)

# 构建测试集
test_faces = search_faces('../data/faces/testing')
test_x, test_y, test_z = [], [], []
for label, filenames in test_faces.items():
    for filename in filenames:
        image = cv.imread(filename)
        gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
        faces = fd.detectMultiScale(gray, 1.1, 2, minSize=(100, 100))
        for l, t, w, h in faces:
            test_x.append(
                gray[t:t + h, l:l + w])
            test_y.append(codec.transform([label])[0])
            a, b = int(w / 2), int(h / 2)
            cv.ellipse(image, (l + a, t + b), (a, b), 0, 0, 360, (255, 0, 255), 2)
            test_z.append(image)
test_y = np.array(test_y)

pred_test_y = []
for face in test_x:
    pred_code = model.predict(face)[0]
    pred_test_y.append(pred_code)
escape = False
while not escape:
    for code, pred_code, image in zip(test_y, pred_test_y, test_z):
        label, pred_label = codec.inverse_transform([code, pred_code])
        text = '{} {} {}'.format(label, '==' if code == pred_code else '!=', pred_label)
        cv.putText(image, text, (10, 60), cv.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 6)
        cv.imshow('Recognizing...', image)
        if cv.waitKey(1000) == 27:
            escape = True
            break
```

### 4. 基于通用分类器的人脸识别

#### 1)显示数据集


```python
import sklearn.datasets as sd
import matplotlib.pyplot as mp


faces = sd.fetch_olivetti_faces('../data/')  # 自动读取，(400, 4096) # 每一列为一个像素，用0-1表示颜色
x = faces.data
y = faces.target
mp.figure('Olivette Faces', dpi=150)
mp.subplots_adjust(left=0.04, bottom=0.04, right=0.96, top=0.96, wspace=0, hspace=0)

rows, cols = 10, 40
for row in range(rows):
    for col in range(cols):
        mp.subplot(rows, cols, row * cols + col + 1)
        if row == 0:
            mp.title(str(col), fontsize=8, color='limegreen')
        if col == 0:
            mp.ylabel(str(row), fontsize=8, color='limegreen')
        mp.xticks(())
        mp.yticks(())
        image = x[y == col][row].reshape(64, 64)
        mp.imshow(image, cmap='gray')
mp.show()
```


![png](output_8_0.png)


#### 2)用SVM分类器实现人脸识别


```python
import sklearn.model_selection as ms
import sklearn.svm as svm
import sklearn.metrics as sm


train_x, test_x, train_y, test_y = ms.train_test_split(x, y, test_size=0.2, random_state=7)

model = svm.SVC(class_weight='balanced')
model.fit(train_x, train_y)

pred_test_y = model.predict(test_x)
cm = sm.confusion_matrix(test_y, pred_test_y)
cr = sm.classification_report(test_y, pred_test_y)
print(cr)

mp.figure('Confusion Matrix', dpi=120)
mp.title('Confusion Matrix', fontsize=20)
mp.xlabel('Predicted Class', fontsize=14)
mp.ylabel('True Class', fontsize=14)
mp.tick_params(labelsize=10)
mp.imshow(cm, interpolation='nearest', cmap='gray')
mp.show()
```

    /Users/haoen110/miniconda3/lib/python3.7/site-packages/sklearn/svm/base.py:193: FutureWarning: The default value of gamma will change from 'auto' to 'scale' in version 0.22 to account better for unscaled features. Set gamma explicitly to 'auto' or 'scale' to avoid this warning.
      "avoid this warning.", FutureWarning)


                  precision    recall  f1-score   support
    
               0       0.00      0.00      0.00         1
               1       0.00      0.00      0.00         1
               2       0.00      0.00      0.00         3
               3       0.00      0.00      0.00         1
               4       0.00      0.00      0.00         1
               5       0.31      1.00      0.48         5
               6       0.00      0.00      0.00         2
               7       0.00      0.00      0.00         2
               8       0.00      0.00      0.00         2
               9       0.00      0.00      0.00         1
              10       0.00      0.00      0.00         1
              11       0.00      0.00      0.00         3
              12       0.00      0.00      0.00         2
              13       0.00      0.00      0.00         2
              14       0.00      0.00      0.00         2
              15       0.00      0.00      0.00         3
              16       0.00      0.00      0.00         1
              17       0.00      0.00      0.00         2
              18       0.00      0.00      0.00         1
              19       0.00      0.00      0.00         1
              20       0.00      0.00      0.00         1
              21       0.00      0.00      0.00         2
              22       0.00      0.00      0.00         3
              23       0.33      1.00      0.50         5
              24       0.00      0.00      0.00         2
              25       0.00      0.00      0.00         1
              26       0.00      0.00      0.00         2
              27       0.00      0.00      0.00         1
              28       0.00      0.00      0.00         2
              29       0.00      0.00      0.00         2
              30       0.00      0.00      0.00         2
              31       0.00      0.00      0.00         0
              32       0.00      0.00      0.00         1
              33       0.00      0.00      0.00         4
              34       0.00      0.00      0.00         1
              35       0.00      0.00      0.00         1
              36       0.31      1.00      0.48         5
              37       0.00      0.00      0.00         3
              38       0.00      0.00      0.00         1
              39       0.00      0.00      0.00         4
    
        accuracy                           0.19        80
       macro avg       0.02      0.07      0.04        80
    weighted avg       0.06      0.19      0.09        80
    


    /Users/haoen110/miniconda3/lib/python3.7/site-packages/sklearn/metrics/classification.py:1437: UndefinedMetricWarning: Precision and F-score are ill-defined and being set to 0.0 in labels with no predicted samples.
      'precision', 'predicted', average, warn_for)
    /Users/haoen110/miniconda3/lib/python3.7/site-packages/sklearn/metrics/classification.py:1439: UndefinedMetricWarning: Recall and F-score are ill-defined and being set to 0.0 in labels with no true samples.
      'recall', 'true', average, warn_for)



![png](output_10_3.png)


#### 3)通过主成分分析(PCA)降维


```python
import numpy as np
# 原始样本
A = np.mat('3 2000; 2 3000; 4 5000; 5 8000; 1 2000', dtype=float)
print('A =', A, sep='\n')
# 归一缩放：各列均值为0，极差为1
mu = A.mean(axis=0)
s = A.max(axis=0) - A.min(axis=0)
X = (A - mu) / s
print('X =', X, sep='\n')
# 协方差矩阵
SIGMA = X.T * X
print('SIGMA =', SIGMA, sep='\n')
# 对协方差矩阵做奇异值分解
U, S, V = np.linalg.svd(SIGMA)
print('U =', U, sep='\n')
# 主成分特征矩阵
U_reduce = U[:, 0]
print('U_reduce =', U_reduce, sep='\n')
# 降维样本
Z = X * U_reduce
print('Z =', Z, sep='\n')
# 近似恢复归一缩放样本
X_approx = Z * U_reduce.T
print('X_approx =', X_approx, sep='\n')
# 近似恢复原始样本
A_approx = np.multiply(X_approx, s) + mu
print('A_approx =', A_approx, sep='\n')
```

    A =
    [[3.e+00 2.e+03]
     [2.e+00 3.e+03]
     [4.e+00 5.e+03]
     [5.e+00 8.e+03]
     [1.e+00 2.e+03]]
    X =
    [[ 0.         -0.33333333]
     [-0.25       -0.16666667]
     [ 0.25        0.16666667]
     [ 0.5         0.66666667]
     [-0.5        -0.33333333]]
    SIGMA =
    [[0.625      0.58333333]
     [0.58333333 0.72222222]]
    U =
    [[-0.67710949 -0.73588229]
     [-0.73588229  0.67710949]]
    U_reduce =
    [[-0.67710949]
     [-0.73588229]]
    Z =
    [[ 0.2452941 ]
     [ 0.29192442]
     [-0.29192442]
     [-0.82914294]
     [ 0.58384884]]
    X_approx =
    [[-0.16609096 -0.18050758]
     [-0.19766479 -0.21482201]
     [ 0.19766479  0.21482201]
     [ 0.56142055  0.6101516 ]
     [-0.39532959 -0.42964402]]
    A_approx =
    [[2.33563616e+00 2.91695452e+03]
     [2.20934082e+00 2.71106794e+03]
     [3.79065918e+00 5.28893206e+03]
     [5.24568220e+00 7.66090960e+03]
     [1.41868164e+00 1.42213588e+03]]



```python
import numpy as np
import sklearn.pipeline as pl
import sklearn.preprocessing as sp
import sklearn.decomposition as dc
# 原始样本
A = np.mat('3 2000; 2 3000; 4 5000; 5 8000; 1 2000', dtype=float)
print('A =', A, sep='\n')
# PCA模型
model = pl.Pipeline([
    ('scaler', sp.MinMaxScaler()),
    ('pca', dc.PCA(n_components=1))])
# 降维样本
Z = model.fit_transform(A)
print('Z =', Z, sep='\n')
# 近似恢复原始样本
A_approx = model.inverse_transform(Z)
print('A_approx =', A_approx, sep='\n')
```

    A =
    [[3.e+00 2.e+03]
     [2.e+00 3.e+03]
     [4.e+00 5.e+03]
     [5.e+00 8.e+03]
     [1.e+00 2.e+03]]
    Z =
    [[-0.2452941 ]
     [-0.29192442]
     [ 0.29192442]
     [ 0.82914294]
     [-0.58384884]]
    A_approx =
    [[2.33563616e+00 2.91695452e+03]
     [2.20934082e+00 2.71106794e+03]
     [3.79065918e+00 5.28893206e+03]
     [5.24568220e+00 7.66090960e+03]
     [1.41868164e+00 1.42213588e+03]]


#### 4)还原率

经过PCA降维后样本，再进过逆向还原，与原始样本相比的误差。


```python
ncps = range(10, 410, 10)
evrs = []
for ncp in ncps:
    model = dc.PCA(n_components=ncp)
    model.fit_transform(x)
    # 还原率误差
    evr = model.explained_variance_ratio_.sum()
    evrs.append(evr)
    
mp.figure('Explained Variance Ratio', dpi=120)
mp.title('Explained Variance Ratio', fontsize=20)
mp.xlabel('n_components', fontsize=14)
mp.ylabel('Explained Variance Ratio', fontsize=14)
mp.tick_params(labelsize=10)
mp.grid(linestyle=':')
mp.plot(ncps, evrs, c='dodgerblue',label='Explained Variance Ratio')
mp.legend()
mp.show()
```


![png](output_15_0.png)



```python
mp.figure('Explained Variance Ratio',dpi=150)
mp.subplots_adjust(left=0.04, bottom=0.04, right=0.96, top=0.96, wspace=0, hspace=0)
rows, cols = 11, 40
for row in range(rows):
    if row > 0:
        ncp = 140 - (row - 1) * 15
        model = dc.PCA(n_components=ncp)
        model.fit(x)
    for col in range(cols):
        mp.subplot(rows, cols, row * cols + col + 1)
        if row == 0:
            mp.title(str(col), fontsize=8,
                     color='limegreen')
        if col == 0:
            mp.ylabel(str(ncp) if row > 0
                      else 'orig', fontsize=8,
                      color='limegreen')
        mp.xticks(())
        mp.yticks(())
        if row > 0:
            pca_x = model.transform([x[y == col][0]])
            ipca_x = model.inverse_transform(pca_x)
            image = ipca_x.reshape(64, 64)
        else:
            image = x[y == col][0].reshape(64, 64)
        mp.imshow(image, cmap='gray')
mp.show()
```


![png](output_16_0.png)


#### 5)用PCA降维改善基于SVM分类器的人脸识别效果


```python
import sklearn.datasets as sd
import sklearn.decomposition as dc
import sklearn.model_selection as ms
import sklearn.svm as svm
import sklearn.metrics as sm
import matplotlib.pyplot as mp


faces = sd.fetch_olivetti_faces('../data/')
x = faces.data
y = faces.target

model = dc.PCA(n_components=140)
pca_x = model.fit_transform(x)

train_x, test_x, train_y, test_y = ms.train_test_split(pca_x, y, test_size=0.2, random_state=7)

model = svm.SVC(class_weight='balanced')
model.fit(train_x, train_y)

pred_test_y = model.predict(test_x)
cm = sm.confusion_matrix(test_y, pred_test_y)
cr = sm.classification_report(test_y, pred_test_y)
print(cr)
mp.figure('Confusion Matrix', dpi=120)
mp.title('Confusion Matrix', fontsize=20)
mp.xlabel('Predicted Class', fontsize=14)
mp.ylabel('True Class', fontsize=14)
mp.tick_params(labelsize=10)
mp.imshow(cm, interpolation='nearest', cmap='gray')
mp.show()
```

                  precision    recall  f1-score   support
    
               0       0.00      0.00      0.00         1
               1       1.00      1.00      1.00         1
               2       1.00      0.67      0.80         3
               3       1.00      1.00      1.00         1
               4       1.00      1.00      1.00         1
               5       1.00      1.00      1.00         5
               6       1.00      1.00      1.00         2
               7       1.00      1.00      1.00         2
               8       1.00      1.00      1.00         2
               9       1.00      1.00      1.00         1
              10       1.00      1.00      1.00         1
              11       1.00      1.00      1.00         3
              12       1.00      1.00      1.00         2
              13       1.00      1.00      1.00         2
              14       1.00      1.00      1.00         2
              15       1.00      1.00      1.00         3
              16       0.50      1.00      0.67         1
              17       1.00      1.00      1.00         2
              18       1.00      1.00      1.00         1
              19       1.00      1.00      1.00         1
              20       1.00      1.00      1.00         1
              21       1.00      1.00      1.00         2
              22       1.00      1.00      1.00         3
              23       1.00      1.00      1.00         5
              24       1.00      1.00      1.00         2
              25       1.00      1.00      1.00         1
              26       1.00      1.00      1.00         2
              27       1.00      1.00      1.00         1
              28       1.00      1.00      1.00         2
              29       1.00      1.00      1.00         2
              30       1.00      1.00      1.00         2
              32       1.00      1.00      1.00         1
              33       1.00      1.00      1.00         4
              34       1.00      1.00      1.00         1
              35       1.00      1.00      1.00         1
              36       1.00      1.00      1.00         5
              37       1.00      1.00      1.00         3
              38       1.00      1.00      1.00         1
              39       0.80      1.00      0.89         4
    
        accuracy                           0.97        80
       macro avg       0.96      0.97      0.96        80
    weighted avg       0.97      0.97      0.97        80
    


    /Users/haoen110/miniconda3/lib/python3.7/site-packages/sklearn/svm/base.py:193: FutureWarning: The default value of gamma will change from 'auto' to 'scale' in version 0.22 to account better for unscaled features. Set gamma explicitly to 'auto' or 'scale' to avoid this warning.
      "avoid this warning.", FutureWarning)
    /Users/haoen110/miniconda3/lib/python3.7/site-packages/sklearn/metrics/classification.py:1437: UndefinedMetricWarning: Precision and F-score are ill-defined and being set to 0.0 in labels with no predicted samples.
      'precision', 'predicted', average, warn_for)



![png](output_18_2.png)


#### 6)核主成分分析(KPCA)

对于在原始维度空间无法线性分割的样本，利用核函数升高其维度，力图在更高维度空间线性可分，而后在选择适当的与原始维度相同的空间做反向投影，得到低维度空间线性可分的样本集。


```python
import sklearn.datasets as sd
import sklearn.decomposition as dc
import matplotlib.pyplot as mp


x, y = sd.make_circles(n_samples=500, factor=0.2, noise=0.04)

model = dc.KernelPCA(kernel='rbf', gamma=1)
kpca_x = model.fit_transform(x)[:, :x.shape[1]]

mp.figure('Original', dpi=120)
mp.title('Original', fontsize=20)
mp.xlabel('x', fontsize=14)
mp.ylabel('y', fontsize=14)
mp.tick_params(labelsize=10)
mp.grid(linestyle=':')
mp.scatter(x[:, 0], x[:, 1], c=y, cmap='brg', alpha=0.5, s=60)

mp.figure('KPCA', dpi=120)
mp.title('KPCA', fontsize=20)
mp.xlabel('x', fontsize=14)
mp.ylabel('y', fontsize=14)
mp.tick_params(labelsize=10)
mp.grid(linestyle=':')
mp.scatter(kpca_x[:, 0], kpca_x[:, 1], c=y, cmap='brg', alpha=0.5, s=60)
mp.show()
```


![png](output_20_0.png)



![png](output_20_1.png)

