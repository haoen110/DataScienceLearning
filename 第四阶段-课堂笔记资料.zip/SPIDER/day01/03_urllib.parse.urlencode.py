import urllib.parse

tedu = {"wd":"达内科技"}
tedu = urllib.parse.urlencode(tedu)
print(tedu)









